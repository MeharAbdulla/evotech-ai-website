Smart Irrigation System
- ESP32 based project
- Auto irrigation using soil moisture sensor
- Web dashboard control included