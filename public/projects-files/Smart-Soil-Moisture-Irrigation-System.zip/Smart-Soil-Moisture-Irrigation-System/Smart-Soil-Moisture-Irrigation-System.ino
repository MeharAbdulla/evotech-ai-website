/*
  Smart Soil Moisture Precision Irrigation System
  Target: ESP32
  Author: ChatGPT Example

  Features:
  - Automatic irrigation
  - Manual pump control from Serial
  - DHT22 (optional)
  - Pump safety timeout
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

#define SOIL_PIN 34
#define RELAY_PIN 26
#define DHTPIN 4
#define DHTTYPE DHT22

const char* ssid = "YOUR_WIFI_NAME";
const char* password = "YOUR_WIFI_PASSWORD";

const int DRY_THRESHOLD = 2500;
const unsigned long MAX_PUMP_RUNTIME = 15000;
const unsigned long SAMPLE_INTERVAL = 5000;

DHT dht(DHTPIN, DHTTYPE);
WebServer server(80);

int soilValue = 0;
float temperature = 0;
float humidity = 0;
bool pumpState = false;
unsigned long lastSample = 0;
unsigned long pumpStart = 0;

void pumpOn() {
  digitalWrite(RELAY_PIN, HIGH);
  pumpState = true;
  pumpStart = millis();
}

void pumpOff() {
  digitalWrite(RELAY_PIN, LOW);
  pumpState = false;
}

void readSensors() {
  soilValue = analogRead(SOIL_PIN);
  temperature = dht.readTemperature();
  humidity = dht.readHumidity();
}

void irrigationLogic() {
  if (soilValue > DRY_THRESHOLD && !pumpState) {
    pumpOn();
  }

  if (pumpState) {
    if (soilValue <= DRY_THRESHOLD || millis() - pumpStart >= MAX_PUMP_RUNTIME) {
      pumpOff();
    }
  }
}

String html() {
  String s;
  s += "<html><head><meta http-equiv='refresh' content='5'></head><body>";
  s += "<h2>ESP32 Smart Irrigation</h2>";
  s += "<p>Soil: " + String(soilValue) + "</p>";
  s += "<p>Temperature: " + String(temperature) + " C</p>";
  s += "<p>Humidity: " + String(humidity) + " %</p>";
  s += "<p>Pump: " + String(pumpState ? "ON" : "OFF") + "</p>";
  s += "<a href='/on'><button>ON</button></a> ";
  s += "<a href='/off'><button>OFF</button></a>";
  s += "</body></html>";
  return s;
}

void handleRoot() {
  server.send(200, "text/html", html());
}

void setup() {
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);

  dht.begin();

  WiFi.begin(ssid, password);

  Serial.print("Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);

  server.on("/on", []() {
    pumpOn();
    server.sendHeader("Location","/");
    server.send(302,"text/plain","");
  });

  server.on("/off", []() {
    pumpOff();
    server.sendHeader("Location","/");
    server.send(302,"text/plain","");
  });

  server.begin();
}

void loop() {
  server.handleClient();

  if (millis() - lastSample >= SAMPLE_INTERVAL) {
    lastSample = millis();

    readSensors();

    Serial.println("---------------");
    Serial.print("Soil: ");
    Serial.println(soilValue);

    Serial.print("Temperature: ");
    Serial.println(temperature);

    Serial.print("Humidity: ");
    Serial.println(humidity);

    irrigationLogic();

    Serial.print("Pump: ");
    Serial.println(pumpState ? "ON" : "OFF");
  }

  if (Serial.available()) {
    char c = Serial.read();
    if (c == '1') pumpOn();
    if (c == '0') pumpOff();
  }
}
